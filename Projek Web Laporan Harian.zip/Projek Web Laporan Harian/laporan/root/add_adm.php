<?php 
session_start();
if (!isset($_SESSION['adm'])) {
  header('location:../home');
}
 ?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../model/upload/apl.png">

    <title>Tambah Admin - Si Laporan Harian</title>

    <link href="../lib/bootstrap.min.css" rel="stylesheet">
    <link href="../lib/dashboard.css" rel="stylesheet">
    
  </head>

  <body>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h3 class="page-header">Tambah Admin Baru</h3>
            <?php 
              if (isset($_GET['st'])) {
                if ($_GET['st']==1) {
                  echo "<div class='alert alert-warning'><strong>Berhasil Ditambahkan.</strong></div>";
                } elseif ($_GET['st']==2) {
                  echo "<div class='alert alert-danger'><strong>Gagal Menambahkan.</strong></div>";
                } elseif ($_GET['st']==3) {
                  echo "<div class='alert alert-danger'><strong>Maaf Email sudah digunakan.</strong></div>";
                } elseif ($_GET['st']==4) {
                  echo "<div class='alert alert-danger'><strong>Kolom tidak boleh kosong.</strong></div>";
                }
              }

             ?>
            <form class="form-horizontal" role="form" style="width:80%" method="post" action="proses.php">
              <div class="form-group">
                <label class="control-label col-sm-2" for="name">Nama Lengkap:</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama" placeholder="Masukan Nama Lengkap" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" name="email" placeholder="Masukkan Alamat Email" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2">Password:</label>
                <div class="col-sm-10"> 
                  <input type="password" class="form-control" name="pwd" placeholder="Masukkan Password" required>
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-default" name="add_pbXia1Zasww12Q">Tambah</button>
                </div>
              </div>
            </form>
        </div>
      </div>
    </div>

    <script src="../lib/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../lib/bootstrap.min.js"></script>

</body></html>