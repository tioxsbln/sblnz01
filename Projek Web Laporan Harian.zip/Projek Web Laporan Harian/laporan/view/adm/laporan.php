<h3 class='page-header'>Riwayat Laporan</h3>
	<div class='table-responsive'>
	<?php 
		if (isset($_GET['id_user'])) {
			if ($_GET['id_user']!=="") {
				$id_user=$_GET['id_user'];
				include './view/note.php';
			} else {
				header("location:laporan");
			}
		} else {
			$sql = "SELECT*FROM detail_user ORDER BY pos_user ASC";
			if ($conn->query($sql)->num_rows!==0) {
				echo "<table class='table table-striped' style='width:50%'>
					<thead>
						<tr>
							<th>No</th>
							<th>Nama Lengkap</th>
							<th>Jabatan/Posisi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>";
				$query_user = $conn->query($sql);
				$no=0;
				while ($get_user = $query_user->fetch_assoc()) {
					$id_user = $get_user['id_user'];
					$name = $get_user['name_user'];
					$jab = $get_user['pos_user'];
					$no++;
					echo "<tr>
							<td>$no</td>
							<td>$name</td>
							<td>$jab</td>
							<td><a href='laporan&id_user=$id_user' title='Laporan $name'>Lihat Laporan</a></td>
						</tr>";
				}
				$conn->close();
				echo "</tbody></table>";
			} else {
				echo "<div class='alert alert-danger'><strong>Tidak ada User untuk ditampilkan</strong></div>";
			}
		}
	 ?>
</div>