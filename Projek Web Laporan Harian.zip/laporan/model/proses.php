<?php 
session_start();
date_default_timezone_set('Asia/Jakarta');
include '../lib/db/dbconfig.php';

if (isset($_POST['login'])) {
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$pwd = sha1(mysqli_escape_string($conn, $_POST['pwd']));

	$sql = "SELECT * FROM user WHERE email_user='$email' AND pwd_user='$pwd'";
	$query = $conn->query($sql);
	$hitung = $query->num_rows;
	
	if ($hitung!==0) {
		$ambil = $query->fetch_assoc();

		extract($ambil);

		
		if ($level_user==='adm') {
			$_SESSION['adm']=$email;
			$_SESSION['id']=$id_user;
			header("Location:../index.php");
		} elseif ($level_user==='usr') {
			$_SESSION['usr']=$email;
			$_SESSION['id']=$id_user;
			header("Location:../index.php");
		}
	}else{
		header("location:../index.php?log=2");
	}
}
elseif (isset($_GET['logout'])) {
	session_destroy();
	
}
    
// Proses User 
    
elseif (isset($_GET['absen'])) {
	if($_GET['absen']==1){
		$month = date("m");
		$day_tgl = date("d");
		$day = date("N");
		$hour = date("H.i")." WIB";
		$status = "Menunggu";
		$sql = "INSERT INTO data_absen (
			id_user,
			id_bln,
			id_hri,
			id_tgl,
			jam_msk,
			st_jam_msk) VALUES (
			?,
			?,
			?,
			?,
			?,
			?)";
		if ($statement = $conn->prepare($sql)) {
			$statement->bind_param(
				"iiiiss", $_SESSION['id'], $month, $day, $day_tgl, $hour, $status
				);
			if ($statement->execute()) {
				$conn->close();
				header("location:../absen&ab=1");
			} else {
				header("location:../absen&ab=2");
			}
		}else {
			header("location:../absen&ab=2");
		}
		
	} else {
		//Absen pulang
		$id_user = mysqli_real_escape_string($conn, $_SESSION['id']);
		$id_bln = date("m");
		$day_tgl = date("d");
		$day = date("N");
		$hour = date("H.i")." WIB";
		$status = "Menunggu";
		$sql = "UPDATE data_absen SET jam_klr=?, st_jam_klr=? WHERE id_user='$id_user' AND id_tgl='$day_tgl' AND id_bln='$id_bln'";

		if ($statement= $conn->prepare($sql)) {
			$statement->bind_param(
				"ss", $hour, $status
				);
			if ($statement->execute()) {
				$conn->close();
				header("location:../absen&ab=1");

			} else {
				header("location:../absen&ab=2");
			}
		} else {
			header("location:../absen&ab=2");
		}
		
	}
}

// Simpan Laporan
elseif (isset($_POST['simpan_note'])) {
	
	if ($note !== "") {
		$id_user = $_SESSION['id'];
		$note = $_POST['note'];
		$month = date("m");
		$day_tgl = date("d");
		$day = date("N");
		$id_note = "NULL";
		$status = "Menunggu";
		$sql= "INSERT INTO laporan (id_lap,
			id_user,
			id_bln,
			id_hri,
			id_tgl,
			isi_lap,
			status_lap) VALUES (?,
			?,
			?,
			?,
			?,
			?,
			?)";
		if ($statement = $conn->prepare($sql)) {
			$statement->bind_param(
				"iiiiiss", $id_note, $id_user, $month, $day, $day_tgl, $note, $status
				);
			if ($statement->execute()) {
				header("location:../laporan&st=1");
				$statement->close();
			} else {
				header("location:../laporan&st=2");
			}
		}else {
			header("location:../laporan&st=2");
		}
	} else {
		header("location:../laporan&st=2");
	}
}

// Proses Admin

    elseif (isset($_GET['accx_absen'])) {
	if (!isset($_SESSION['adm'])) {
		header("location:home");
	}else{
		$id_absen=$_GET['accx_absen'];
		$type = $_GET['type'];
		if ($type==="in") {
			$query = "UPDATE data_absen SET st_jam_msk=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Dikonfirmasi";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					echo "Sukses";
				}else{
					
					echo "Gagal";
				}
				$conn->close();
			} else {
				echo "Ga siap";
			}
			
		} else {
			$query = "UPDATE data_absen SET st_jam_klr=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Dikonfirmasi";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					echo "Sukses";
				}else{
					
					echo "Gagal";
				}
				$conn->close();
			} else {
				echo "Ga siap";
			}
		}
	}
}
        
// Admin acc absen
elseif (isset($_GET['acc_absen'])) {
	if (!isset($_SESSION['adm'])) {
		header("location:home");
	}else{
		$id_absen=$_GET['acc_absen'];
		$type = $_GET['type'];
		if ($type==="in") {
			$query = "UPDATE data_absen SET st_jam_msk=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Dikonfirmasi";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					header("location:../absen&ab=1");
				}else{
					
					header("location:../absen&ab=2");
				}
				$conn->close();
			} else {
				header("location:../absen&ab=2");
			}
			
		} else {
			$query = "UPDATE data_absen SET st_jam_klr=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Dikonfirmasi";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					header("location:../absen&ab=1");
				}else{
					
					header("location:../absen&ab=2");
				}
				$conn->close();
			} else {
				header("location:../absen&ab=2");
			}
		}
	}
}
// Acc absen 2
elseif (isset($_POST['acc_absen2'])) {
	
	if (!empty($_POST['id_absen'])) {
		$count_id = count($_POST["id_absen"]);
		for($i=0; $i < $count_id; $i++) 
		{
		    $item=explode(",", $_POST["id_absen"][$i]);
		    $id_absen = "$item[0]";
		    $type = "$item[1]";
		    
		    if ($type==="in") {
				$query = "UPDATE data_absen SET st_jam_msk=? WHERE id_absen='$id_absen'";
				if ($statement = $conn->prepare($query)) {
					$status = "Dikonfirmasi";
					$statement->bind_param(
						"s", $status);
					if ($statement->execute()) {
						
						header("location:../absen&ab=1");
					}else{
						
						header("location:../absen&ab=2");
					}
					
				} else {
					header("location:../absen&ab=6");
				}
				
			} else {
				$query = "UPDATE data_absen SET st_jam_klr=? WHERE id_absen='$id_absen'";
				if ($statement = $conn->prepare($query)) {
					$status = "Dikonfirmasi";
					$statement->bind_param(
						"s", $status);
					if ($statement->execute()) {
						
						header("location:../absen&ab=1");
					}else{
						
						header("location:../absen&ab=2");
					}
					
				} else {
					header("location:../absen&ab=2");
				}
			}
		}
		$conn->close();
	} else {
		header("location:../absen&ab=2");
	}

}
        
// Admin tolak absen
elseif (isset($_GET['dec_absen'])) {
	if (!isset($_SESSION['adm'])) {
		header("location:home");
	}else{
		$id_absen=$_GET['dec_absen'];
		$type = $_GET['type'];
		if ($type==="in") {
			$query = "UPDATE data_absen SET st_jam_msk=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Ditolak";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					header("location:../absen&ab=3");
				}else{
					
					header("location:../absen&ab=2");
				}
				$conn->close();
			} else {
				header("location:../absen&ab=2");
			}
			
		} else {
			$query = "UPDATE data_absen SET st_jam_klr=? WHERE id_absen='$id_absen'";
			if ($statement = $conn->prepare($query)) {
				$status = "Ditolak";
				$statement->bind_param(
					"s", $status);
				if ($statement->execute()) {
					
					header("location:../absen&ab=3");
				}else{
					
					header("location:../absen&ab=2");
				}
				$conn->close();
			} else {
				header("location:../absen&ab=2");
			}
		}
	}
}
// tolak absen 2
elseif (isset($_POST['dec_absen2'])) {
	
	if (!empty($_POST['id_absen'])) {
		$count_id = count($_POST["id_absen"]);
		for($i=0; $i < $count_id; $i++) 
		{
		    $item=explode(",", $_POST["id_absen"][$i]);
		    $id_absen = "$item[0]";
		    $type = "$item[1]";
		    
		    if ($type==="in") {
				$query = "UPDATE data_absen SET st_jam_msk=? WHERE id_absen='$id_absen'";
				if ($statement = $conn->prepare($query)) {
					$status = "Ditolak";
					$statement->bind_param(
						"s", $status);
					if ($statement->execute()) {
						
						header("location:../absen&ab=3");
					}else{
						
						header("location:../absen&ab=2");
					}
					
				} else {
					header("location:../absen&ab=2");
				}
				
			} else {
				$query = "UPDATE data_absen SET st_jam_klr=? WHERE id_absen='$id_absen'";
				if ($statement = $conn->prepare($query)) {
					$status = "Ditolak";
					$statement->bind_param(
						"s", $status);
					if ($statement->execute()) {
						
						header("location:../absen&ab=3");
					}else{
						
						header("location:../absen&ab=2");
					}
					
				} else {
					header("location:../absen&ab=2");
				}
			}
		}
		$conn->close();
	} else {
		header("location:../absen&ab=2");
	}
}
        
// laporan
elseif (isset($_GET['acc_note'])) {
	if (!isset($_SESSION['adm'])) {
		header("location:home");
	}else{
		$id_note=$_GET['acc_note'];
		$sql = "UPDATE laporan SET status_lap=? WHERE id_lap='$id_note'";
		if ($statement = $conn->prepare($sql)) {
			$status= "Dikonfirmasi";
			$statement->bind_param(
				"s", $status
				);
			if ($statement->execute()) {
				header("location:../req_laporan&ab=1");
			}else{
		
				header("location:../req_laporan&ab=2");
			}
			$conn->close();
		} else {
			header("location:../req_laporan&ab=2");
		}
		
	}
}
        
// tolak laporan
elseif (isset($_GET['dec_note'])) {
	if (!isset($_SESSION['adm'])) {
		header("location:../home");
	}else{
		$id_note=$_GET['dec_note'];
		$sql = "UPDATE laporan SET status_lap=? WHERE id_lap='$id_note'";
		if ($statement = $conn->prepare($sql)) {
			$status= "Ditolak";
			$statement->bind_param(
				"s", $status
				);
			if ($statement->execute()) {
				header("location:../req_laporan&ab=3");
			}else{
				
				header("location:../req_laporan&ab=2");
			}
			$conn->close();
		} else {
			header("location:../req_laporan&ab=2");
		}
		
	}
}
        
// add user
elseif (isset($_POST['add_user'])) {
	$query = $conn->query("SELECT id_user FROM user ORDER BY id_user DESC");
	$ambil = $query->fetch_assoc();
	$id = $ambil['id_user']+1;
	$nik = mysqli_real_escape_string($conn, $_POST['nik']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$pwd = mysqli_real_escape_string($conn, sha1($_POST['pwd_cek']));
	$pwd_cek = mysqli_real_escape_string($conn, sha1($_POST['pwd']));
	
	$nama = mysqli_real_escape_string($conn, $_POST['nama']);
	$jk = mysqli_real_escape_string($conn, $_POST['jk']);
	$pos = mysqli_real_escape_string($conn, $_POST['pos']);
	$level = "usr";
	
	$sql_user = "INSERT INTO user (id_user,
		email_user,
		pwd_user,
		level_user) VALUES(?,
		?,
		?,
		?)";
	$sql_detail = "INSERT INTO detail_user (id_user,
		nik_user,
		name_user,
		pos_user,
		jk_user) VALUES(?,
		?,
		?,
		?,
		?)";
	if ($nik==="" || $email==="" || $pwd==="" || $nama==="" || $jk==="" || $pos==="") {
		header("location:../add_user&st=4");
	}else {
		if ($pwd !== "$pwd_cek") {
			header("location:../add_user&st=5");
		} else {
			$cek =$conn->query("SELECT*FROM user WHERE email_user='$email'")->num_rows;
			$cek_nik = $conn->query("SELECT (nik_user) FROM detail_user WHERE nik_user='$nik'")->num_rows;
			if ($cek==0) {
				if ($cek_nik==0) {
					if ($statement= $conn->prepare($sql_user) AND $statement1 = $conn->prepare($sql_detail)) {
						$statement->bind_param(
							"isss", $id, $email, $pwd, $level
							);
						$statement1->bind_param(
							"iisss", $id, $nik, $nama, $pos, $jk
							);
						if ($statement->execute() && $statement1->execute()) {
							header("location:../add_user&st=1");
						} else {
							header("location:../add_user&st=2");
						}
					} else {
						header("location:../add_user&st=2");
					}
				} else {
					header("location:../add_user&st=6");
				}
				$conn->close();
			} else {
				header("location:../add_user&st=3");
			}
		}
	}
	
}
    
// edit user
elseif (isset($_POST['edit_user'])) {
	$id = mysqli_real_escape_string($conn, $_POST['id_user']);
	$nik = mysqli_real_escape_string($conn, $_POST['nik']);
	$nama = mysqli_real_escape_string($conn, $_POST['nama']);
	$jk = mysqli_real_escape_string($conn, $_POST['jk']);
	$pos = mysqli_real_escape_string($conn, $_POST['pos']);

	$sql_detail = "UPDATE detail_user SET nik_user=?, name_user=?, pos_user=?, jk_user=? WHERE id_user='$id'";
	if ($nik==="" || $id==="" || $nama==="" || $jk==="" || $pos==="") {
		header("location:../user&id=$id&st=4");
	}else {
		if ($statement= $conn->prepare($sql_detail)) {
				$statement->bind_param(
					"ssss", $nik, $nama, $pos, $jk
					);
				if ($statement->execute()) {
					header("location:../user&id_user=$id&st=1");
				} else {
					header("location:../user&id_user=$id&st=2");
				}
			} else {
				header("location:../user&id_user=$id&st=2");
			}
		$conn->close();
		
	}
	
}
// hapus user
elseif (isset($_GET['del_user'])) {
	$id = mysqli_real_escape_string($conn, $_GET['del_user']);
	$sql_d = "DELETE FROM detail_user WHERE id_user=?";
	$sql_u = "DELETE FROM user WHERE id_user=?";
	if ($stmt= $conn->prepare($sql_d) AND $stmt1 = $conn->prepare($sql_u)) {
		$stmt->bind_param("i", $id);
		$stmt1->bind_param("i", $id);
		if ($stmt->execute() && $stmt1->execute()) {
			header("location:../user&st=3");
		} else {
			header("location:../user&st=5");
		}
	} else {
		header("location:../user&st=5");
	}
}
// Ganti password
elseif (isset($_POST['change-pwd'])) {
	$id = mysqli_real_escape_string($conn, $_POST['id']);
	$old = sha1(mysqli_real_escape_string($conn, $_POST['old-pwd']));
	$new = sha1(mysqli_real_escape_string($conn, $_POST['new-pwd']));
	$cek = sha1(mysqli_real_escape_string($conn, $_POST['new-pwd-cek']));
	if (!empty($old) || !empty($new) || !empty($cek) || !empty($id)) {
			if ($new !== $cek) {
				header("location:../katasandi&id=$id&st=5");
			} else {
				$sqlc = "UPDATE user SET pwd_user=? WHERE id_user='$id'";
				if ($update= $conn->prepare($sqlc)) {
					$update->bind_param("s", $new);
					if ($update->execute()) {
						header("location:../katasandi&id=$id&st=1");
					} else {
						header("location:../katasandi&id=$id&st=2");
					}
				} else {
					header("location:../katasandi&id=$id&st=2");
				}
			}
	} else {
		header("location:../katasandi&id=$id&st=4");
	}
}
        
else {
	echo "<script>window.alert('Terjadi Kesalahan.');window.location=('../home');</script>";
}
?>