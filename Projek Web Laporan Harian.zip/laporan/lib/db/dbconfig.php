<?php 
    
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpwd = "";
    $dbname = "laporan";

    $conn = new mysqli($dbhost, $dbuser, $dbpwd, $dbname);
 ?>
