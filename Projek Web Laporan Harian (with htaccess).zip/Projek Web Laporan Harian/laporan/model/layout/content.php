<?php
if (strcmp($page, "absen")==0) {
        if (isset($_SESSION['usr'])) {
          include './view/absen.php';
        } elseif (isset($_SESSION['adm'])) {
          include './view/adm/absen.php';
        }
      }elseif (strcmp($page, "absensi")==0) {
        
        if (isset($_SESSION['usr'])) {
          include './view/detail_absen.php';
          } elseif (isset($_SESSION['adm'])) {
            include './view/adm/detail_absen.php';
          }
      }elseif (strcmp($page, "laporan")==0) {
        
        if (isset($_SESSION['usr'])) {
          include './view/note.php';
          } elseif (isset($_SESSION['adm'])) {
            include './view/adm/laporan.php';
          }
      }elseif (strcmp($page, "tambah_laporan")==0) {
        include './view/add_note.php';
      }elseif (strcmp($page, "req_laporan")==0) {
        if (!isset($_SESSION['adm'])) {
            header("location:home");
        }else {
            include './view/adm/req_laporan.php';
        }
      } elseif (strcmp($page, "add_user")==0) {
        if (!isset($_SESSION['adm'])) {
            header("location:home");
        }else {
            include './view/adm/add_user.php';
        }
      } elseif (strcmp($page, "user")==0) {
        if (!isset($_SESSION['adm'])) {
            header("location:home");
        }else {
            include './view/adm/user.php';
        }
      } elseif (strcmp($page, "katasandi")==0) {
        if (!isset($_SESSION['adm'])) {
            header("location:home");
        }else {
            include './view/adm/katasandi.php';
        }
      } elseif (strcmp($page, "keluar")==0) {
        echo "<script>
        if (confirm('Kamu yakin ingin logout dari aplikasi?')) {
            window.location.href = 'view/logout.php';
        } else {
            window.location.href = 'home'; 
        }
      </script>";
      } else {
        header("location:absen");
      }
?>