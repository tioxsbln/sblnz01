- Admin
user : admin@gmail.com
pass : 123


- User Demo
user : fariz@gmail.com
pass : 123


- Link Tambah Admin Baru (Harus Login Sebagai Admin)
localhost(alamat domain)/laporan/root/add_adm.php