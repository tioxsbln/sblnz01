<h3 class='page-header'>Riwayat Absensi</h3>
	<div class='table-responsive'>
	<?php 
		if (isset($_GET['id_user'])) {
			if ($_GET['id_user']!=="") {
				$id_user=$_GET['id_user'];
				include './view/detail_absen.php';
			} else {
				header("location:absensi");
			}
		} else {
			$sql = "SELECT*FROM detail_user ORDER BY nik_user ASC";
			$query = $conn->query($sql);
			if ($query->num_rows!==0) {
				echo "<table class='table table-striped' style='width:50%'>
					<thead>
						<tr>
							<th>No</th>
							<th>NIK</th>
							<th>Nama Lengkap</th>
							<th>Jabatan/Posisi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>";
				$no=0;
				while ($get_user = $query->fetch_assoc()) {
					$id_user = $get_user['id_user'];
					$nik = $get_user['nik_user'];
					$name = $get_user['name_user'];
					$jab = $get_user['pos_user'];
					$no++;
					echo "<tr>
							<td>$no</td>
							<td><strong>$nik</strong></td>
							<td>$name</td>
							<td>$jab</td>
							<td><strong><a href='absensi&id_user=$id_user' title='Absensi $name'>Riwayat Absensi</a></strong></td>
						</tr>";
				}
				echo "</tbody></table>";
				$conn->close();
			} else {
				echo "<div class='alert alert-danger'><strong>Tidak ada User untuk ditampilkan</strong></div>";
			}
		}
	 ?>
</div>